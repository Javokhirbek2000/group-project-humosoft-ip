<h2>Products</h2>
<div class="table-responsive custom-table">
  <table class="table table-striped table-sm">
    <thead>
      <tr>
        <th>#</th>
        <th>Image</th>
        <th>Name</th>
        <th>Quantity</th>
        <th>Price</th>
        <th>Featured</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = App\Models\Product::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($product->id); ?></td>
          <td>
            <div class="img-wrapper mx-auto square-75 overflow-hidden">
              <img class="w-100 h-100" src="<?php echo e($product->imagesList()[0]); ?>" class="img-thumbnail" alt="<?php echo e($product->name); ?>">
            </div>
          </td>
          <td><?php echo e($product->name); ?></td>
          <td><?php echo e($product->available); ?></td>
          <td><?php echo e($product->price); ?></td>
          <td><i class="bi <?php echo e($product->is_featured ? "bi-check2-all text-success" : "bi-x-circle text-danger"); ?> "></i></td>
          <td><a href="#" class="btn btn-info text-white"><i class="bi bi-pencil"></i></a></td>
          <td><a href="#" class="btn btn-danger text-white"><i class="bi bi-trash"></i></a></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
<?php /**PATH C:\Users\www\Desktop\INHA\IP\PROJETCS\group-project-humosoft-ip\resources\views/pages/admin/products.blade.php ENDPATH**/ ?>