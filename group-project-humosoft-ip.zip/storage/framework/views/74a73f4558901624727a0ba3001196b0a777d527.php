<section <?php echo e($attributes->merge(['class' => 'section'])); ?>>
  <div class="container">
    <div class="title d-flex justify-content-center align-items-center mb-5">
      <h2 class="text-center p-4 shadow bg-white rounded"><?php echo e($attributes['title']); ?></h2>
    </div>
    <?php echo e($slot); ?>

  </div>
</section>
<?php /**PATH C:\Users\www\Desktop\INHA\IP\PROJETCS\group-project-humosoft-ip\resources\views/components/section.blade.php ENDPATH**/ ?>