<div id="bannerSlider" class="carousel slide banner-slider " data-bs-ride="carousel">
  <div class="carousel-indicators">
    <?php $__currentLoopData = App\Models\Banner::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <button type="button" data-bs-target="#bannerSlider" data-bs-slide-to="<?php echo e($i); ?>"
        class="<?php echo e($i == 0 ? 'active' : ''); ?>" aria-current="<?php echo e($i == 0); ?>"
        aria-label="<?php echo e($banner->name); ?>"></button>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>
  <div class="carousel-inner">
    <?php $__currentLoopData = App\Models\Banner::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="carousel-item <?php echo e($i == 0 ? 'active' : ''); ?>">

        <div class="img-mask h-80vh"></div>
        <img src="<?php echo e($banner->image); ?>" class="d-block w-100 h-80vh object-fit-cover" alt="<?php echo e($banner->name); ?>">

        <div class="carousel-caption d-block z-index-2 top-50 start-50 translate-middle w-75">
          <h4 class="text-uppercase"><?php echo e($banner->name); ?></h4>
          <h1 class="text-uppercase mb-5"><?php echo e($banner->description); ?></h1>
          <a href="<?php echo e($banner->url); ?>" class="btn btn-outline-light">SHOP NOW</a>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#bannerSlider" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#bannerSlider" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
<?php /**PATH C:\Users\www\Desktop\INHA\IP\PROJETCS\group-project-humosoft-ip\resources\views/partials/banners.blade.php ENDPATH**/ ?>