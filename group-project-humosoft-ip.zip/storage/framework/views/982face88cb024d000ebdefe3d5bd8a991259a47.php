<?php $attributes = $attributes->exceptProps(['options' => ['mode' => 'secondary']]); ?>
<?php foreach (array_filter((['options' => ['mode' => 'secondary']]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
$class = 'whitespace-nowrap inline-flex items-center justify-center px-4 py-2 border border-transparent shadow-sm text-base font-medium text-white bg-black hover:bg';
if ($options['mode'] == 'secondary') {
    $class = 'whitespace-nowrap text-base font-medium px-4 py-2 text-gray-500 border border-black hover:text-white hover:bg-black';
}
?>

<a <?php echo e($attributes->merge(['class' => $class])); ?> class="<?php echo e($class); ?>">
  <?php echo e($slot); ?>

</a>
<?php /**PATH C:\Users\www\Desktop\INHA\IP\PROJETCS\group-project-humosoft-ip\resources\views/components/clickables/link.blade.php ENDPATH**/ ?>