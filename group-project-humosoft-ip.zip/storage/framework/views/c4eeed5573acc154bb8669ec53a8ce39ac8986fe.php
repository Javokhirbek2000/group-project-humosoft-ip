<h2>Banners</h2>
<div class="table-responsive custom-table">
  <table class="table table-striped table-sm">
    <thead>
      <tr>
        <th>#</th>
        <th>Image</th>
        <th>Name</th>
        <th>Info</th>
        <th>Url</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = App\Models\Banner::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($banner->id); ?></td>
          <td>
            <div class="img-wrapper mx-auto square-75 overflow-hidden">
              <img class="w-100 h-100" src="<?php echo e($banner->image); ?>" class="img-thumbnail" alt="<?php echo e($banner->name); ?>">
            </div>
          </td>
          <td><?php echo e($banner->name); ?></td>
          <td><?php echo e($banner->description); ?></td>
          <td><?php echo e($banner->url); ?></td>
          <td><a href="#" class="btn btn-info text-white"><i class="bi bi-pencil"></i></a></td>
          <td><a href="#" class="btn btn-danger text-white"><i class="bi bi-trash"></i></a></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
<?php /**PATH C:\Users\www\Desktop\INHA\IP\PROJETCS\group-project-humosoft-ip\resources\views/pages/admin/banners.blade.php ENDPATH**/ ?>