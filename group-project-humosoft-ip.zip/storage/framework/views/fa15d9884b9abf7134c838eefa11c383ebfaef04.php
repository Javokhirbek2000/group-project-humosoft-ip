<h2>Banners</h2>
<div class="table-responsive custom-table">
  <table class="table table-striped table-sm">
    <thead>
      <tr>
        <th>#</th>
        <th>Image</th>
        <th>Name</th>
        <th>Featured</th>
        <th>Products Count</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = App\Models\Collection::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $collection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($collection->id); ?></td>
          <td>
            <div class="img-wrapper square-75 mx-auto overflow-hidden">
              <img class="w-100 h-100" src="<?php echo e($collection->image); ?>" class="img-thumbnail" alt="<?php echo e($collection->name); ?>">
            </div>
          </td>
          <td><?php echo e($collection->name); ?></td>
          <td><i class="bi <?php echo e($collection->is_featured ? "bi-check2-all text-success" : "bi-x-circle text-danger"); ?> "></i></td>
          <td><?php echo e(count($collection->products)); ?></td>
          <td><a href="#" class="btn btn-info text-white"><i class="bi bi-pencil"></i></a></td>
          <td><a href="#" class="btn btn-danger text-white"><i class="bi bi-trash"></i></a></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
<?php /**PATH C:\Users\www\Desktop\INHA\IP\PROJETCS\group-project-humosoft-ip\resources\views/pages/admin/collections.blade.php ENDPATH**/ ?>