

<?php $__env->startSection('content'); ?>
  <?php switch($slug):
    case ("banners"): ?>
      <?php echo $__env->make('pages.admin.banners', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php break; ?>
    <?php case ("collections"): ?>
      <?php echo $__env->make('pages.admin.collections', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php break; ?>
    <?php case ("products"): ?>
      <?php echo $__env->make('pages.admin.products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php break; ?>
    <?php default: ?>
      <?php echo $__env->make('pages.admin.banners', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php endswitch; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\www\Desktop\INHA\IP\PROJETCS\group-project-humosoft-ip\resources\views/pages/admin.blade.php ENDPATH**/ ?>