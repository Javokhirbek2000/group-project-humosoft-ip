<footer>
    <div class="bg-light py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-4 col-md-6 col-sm-12 text-center text-md-start">
                <a href="/" class="d-block text-decoration-none my-2">Home</a>
                <a href="/about" class="d-block text-decoration-none my-2">About</a>
                <a href="/contact" class="d-block text-decoration-none my-2">Contact</a>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-12 text-center text-md-start">
                <a href="#" class="d-block text-decoration-none my-2"><i class="bi bi-facebook me-2"></i>Facebook</a>
                <a href="#" class="d-block text-decoration-none my-2"><i class="bi bi-instagram me-2"></i>Instagram</a>
                <a href="#" class="d-block text-decoration-none my-2"><i class="bi bi-telegram me-2"></i>Telegram</a>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-12 text-center text-md-start">
                &copy;  &nbsp; 2021 <strong>Humosoft</strong>
                <div>
                    <i class="bi bi-geo-alt me-2"></i>
                    9, Ziyolilar st, Mirzo Ulugbek dt, Tashkent, Uzbekistan
                </div>
            </div>
        </div>
    </div>
    </div>
</footer>
