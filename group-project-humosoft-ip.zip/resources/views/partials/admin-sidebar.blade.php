<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse h-100" style="">
  <div class="position-sticky pt-3">
    <ul class="nav flex-column">
      <li class="nav-item">
        <a class="nav-link active" aria-current="page" href="/admin/banners">
          <i class="bi bi-view-stacked"></i>
          Banners
        </a>
        <a class="nav-link active" aria-current="page" href="/admin/collections">
          <i class="bi bi-collection"></i>
          Collections
        </a>
        <a class="nav-link active" aria-current="page" href="/admin/products">
          <i class="bi bi-basket"></i>
          Products
        </a>
        <a class="nav-link active" aria-current="page" href="/admin/products">
          <i class="bi bi-people"></i>
          Users
        </a>
      </li>
    </ul>
  </div>
</nav>
