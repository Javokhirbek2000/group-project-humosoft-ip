<?php

return [

    'app_title' => 'HumoShop',

];
